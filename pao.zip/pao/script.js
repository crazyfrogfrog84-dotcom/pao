// ── Config ──────────────────────────────────────────
const API_BASE = 'https://your-railway-app.railway.app/api'; // ⬅ Replace with actual Railway URL

// ── State ───────────────────────────────────────────
let subjects = [];

// ── DOM refs ────────────────────────────────────────
const subjectName  = document.getElementById('subjectName');
const subjectGrade = document.getElementById('subjectGrade');
const subjectUnits = document.getElementById('subjectUnits');
const addBtn       = document.getElementById('addSubjectBtn');
const tableBody    = document.getElementById('tableBody');
const emptyState   = document.getElementById('emptyState');
const calculateBtn = document.getElementById('calculateBtn');
const clearBtn     = document.getElementById('clearBtn');
const resultPanel  = document.getElementById('resultPanel');
const gwaValue     = document.getElementById('gwaValue');
const gwaBadge     = document.getElementById('gwaBadge');
const gwaRemark    = document.getElementById('gwaRemark');
const statusPill   = document.getElementById('statusPill');
const statusText   = document.getElementById('statusText');

// ── Helpers ─────────────────────────────────────────
function updateStatus() {
  const n = subjects.length;
  statusText.textContent = n === 0 ? '0 subjects' : `${n} subject${n > 1 ? 's' : ''}`;
  statusPill.classList.toggle('active', n > 0);
}

function hideResult() {
  resultPanel.classList.add('hidden');
}

// ── Render ───────────────────────────────────────────
function renderTable() {
  const isEmpty = subjects.length === 0;
  emptyState.style.display = isEmpty ? 'flex' : 'none';

  if (isEmpty) {
    tableBody.innerHTML = '';
    return;
  }

  tableBody.innerHTML = subjects.map((s, i) => `
    <div class="table-row" style="animation-delay:${i * 30}ms">
      <span class="row-name">${s.name || '—'}</span>
      <span class="row-grade">${s.grade.toFixed(2)}</span>
      <span class="row-units">${s.units}</span>
      <button class="btn-delete" data-index="${i}" aria-label="Remove ${s.name}">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M2 2l10 10M12 2L2 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
  `).join('');

  tableBody.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = parseInt(e.currentTarget.dataset.index);
      subjects.splice(idx, 1);
      renderTable();
      updateStatus();
      hideResult();
    });
  });
}

// ── Add Subject ──────────────────────────────────────
addBtn.addEventListener('click', () => {
  const name  = subjectName.value.trim();
  const grade = parseFloat(subjectGrade.value);
  const units = parseFloat(subjectUnits.value);

  if (!name)                              return flash(subjectName,   'Enter a subject name');
  if (isNaN(grade) || grade < 1 || grade > 5) return flash(subjectGrade, 'Grade must be 1.0 – 5.0');
  if (isNaN(units) || units <= 0)         return flash(subjectUnits,  'Units must be positive');

  subjects.push({ name, grade, units });
  renderTable();
  updateStatus();
  hideResult();

  subjectName.value  = '';
  subjectGrade.value = '';
  subjectUnits.value = '';
  subjectName.focus();
});

// Enter key submits from any field
[subjectName, subjectGrade, subjectUnits].forEach(el => {
  el.addEventListener('keydown', e => { if (e.key === 'Enter') addBtn.click(); });
});

// ── Clear All ────────────────────────────────────────
clearBtn.addEventListener('click', () => {
  if (!subjects.length) return;
  subjects = [];
  renderTable();
  updateStatus();
  hideResult();
});

// ── Flash invalid field ───────────────────────────────
function flash(input, msg) {
  input.style.borderColor = 'var(--danger)';
  input.focus();
  setTimeout(() => { input.style.borderColor = ''; }, 1400);
}

// ── Calculate GWA ────────────────────────────────────
calculateBtn.addEventListener('click', async () => {
  if (!subjects.length) return;

  const payload = subjects.map(s => ({ grade: s.grade, units: s.units }));

  calculateBtn.disabled = true;
  calculateBtn.textContent = 'COMPUTING…';

  try {
    const res = await fetch(`${API_BASE}/gwa/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(err || 'Calculation failed');
    }

    const { gwa } = await res.json();
    displayResult(parseFloat(gwa));

  } catch (err) {
    console.error(err);
    alert(`Error: ${err.message}`);
  } finally {
    calculateBtn.disabled = false;
    calculateBtn.innerHTML = `COMPUTE GWA <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }
});

// ── Display result ────────────────────────────────────
function displayResult(gwa) {
  gwaValue.textContent = gwa.toFixed(2);

  const standing = getStanding(gwa);
  gwaBadge.textContent  = standing.badge;
  gwaRemark.textContent = standing.remark;

  resultPanel.classList.remove('hidden');
  resultPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function getStanding(gwa) {
  if (gwa <= 1.25) return { badge: 'SUMMA CUM LAUDE',  remark: 'Outstanding academic performance.' };
  if (gwa <= 1.50) return { badge: 'SUMMA CUM LAUDE',  remark: 'Exceptional standing.' };
  if (gwa <= 1.75) return { badge: 'MAGNA CUM LAUDE',  remark: 'Excellent academic standing.' };
  if (gwa <= 2.00) return { badge: 'CUM LAUDE',        remark: 'Very good academic standing.' };
  if (gwa <= 2.50) return { badge: 'GOOD STANDING',    remark: 'Above average performance.' };
  if (gwa <= 3.00) return { badge: 'PASSING',          remark: 'Satisfactory standing.' };
  return              { badge: 'NEEDS IMPROVEMENT', remark: 'Consider seeking academic support.' };
}

// ── Init ──────────────────────────────────────────────
renderTable();
updateStatus();
